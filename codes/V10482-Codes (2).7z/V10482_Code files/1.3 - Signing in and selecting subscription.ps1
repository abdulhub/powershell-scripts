Set-location c:\
Clear-Host

Login-AzureRMAccount

Select-AzureRMSubscription "Visual Studio Ultimate with MSDN"