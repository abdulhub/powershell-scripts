Set-location c:\
Clear-Host

Find-Module AzureRM

Find-Module AzureRM | Install-Module -AllowClobber -Force -Scope CurrentUser -Verbose

