﻿Login-AzureRmAccount
Enable-AzureRmContextAutosave
Clear-Host
